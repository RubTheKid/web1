
import { StyleSheet, Text, View } from 'react-native';


export const styles =  StyleSheet.create({
    header: {
      flex: 1,
      paddingTop: 54,
      alignItems: 'center',
      backgroundColor: '#FAEBD7'
    },
  });
  